/*
  DESPERTADOR INTELIGENTE - versión final
  ESP32 + sensores + actuadores + pantalla TFT 3.5" + Firebase

  Conexiones (etiqueta de la placa = GPIO):
    PIR D27 | DHT11 D23 | LDR D34 | MQ-135 D35 | Proximidad (obstáculos IR) D33
    LED simple D25 | LED RGB D13 (R), D14 (G), D32 (B) | Motor vibrador D19
    Módulo MP3-TF-16P: TX -> RX2 (16), RX -> TX2 (17) con 1k
    Pantalla TFT: SCL D18, SDA D21, RST D22, DC D4, CS D5, BL D26

  Librerías: GFX Library for Arduino, DHT sensor library, DFRobotDFPlayerMini, ArduinoJson (v7)
*/
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "time.h"
#include <DHT.h>
#include <Arduino_GFX_Library.h>
#include <DFRobotDFPlayerMini.h>
#include "secrets.h"

// --- Pines ---
#define PIR_PIN 27
#define DHT_PIN 23
#define LDR_PIN 34
#define MQ135_PIN 35
#define PROX_PIN 33                // sensor de obstáculos IR: LOW = detecta algo
#define LED_PIN 25
#define RGB_R 13
#define RGB_G 14
#define RGB_B 32
#define VIBRADOR_PIN 19
#define DF_RX 16                   // RX2 del ESP32 <- TX del módulo MP3
#define DF_TX 17                   // TX2 del ESP32 -> RX del módulo MP3 (con 1k)
#define TFT_SCK 18
#define TFT_MOSI 21
#define TFT_RST 22
#define TFT_DC 4
#define TFT_CS 5
#define TFT_BL 26

// --- Ajustes ---
#define CONTROLADOR_ST7796        // cambia a CONTROLADOR_ST7796 si la pantalla no muestra nada
#define RGB_ANODO_COMUN false      // true si tu LED RGB es de ánodo común
#define TIEMPO_ENCENDIDA 8000      // la pantalla se apaga tras 8 s sin movimiento
#define DURACION_ALARMA 20000
#define UMBRAL_OSCURIDAD 1500      // luz menor a esto = oscuro (igual que la app)
#define UMBRAL_AIRE 2500           // aire mayor a esto = mala calidad (igual que la app)
#define VOLUMEN 20                 // 0 a 30

const unsigned long INTERVALO_LECTURA = 2000;
const unsigned long INTERVALO_ESTADO = 15000;
const unsigned long INTERVALO_HISTORIAL = 60000;
const unsigned long INTERVALO_CONFIG = 20000;
const unsigned long VIDA_TOKEN = 50UL * 60 * 1000;

const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = -3 * 3600;
const int daylightOffset_sec = 0;

// --- Pantalla ---
Arduino_DataBus *bus = new Arduino_ESP32SPI(TFT_DC, TFT_CS, TFT_SCK, TFT_MOSI, GFX_NOT_DEFINED);
#if defined(CONTROLADOR_ST7796)
Arduino_GFX *gfx = new Arduino_ST7796(bus, TFT_RST, 1, false);
#else
Arduino_GFX *gfx = new Arduino_ILI9488_18bit(bus, TFT_RST, 1, false);
#endif
uint16_t COL_BG, COL_CARD, COL_AMB, COL_TX, COL_MU, COL_RED;

DHT dht(DHT_PIN, DHT11);
DFRobotDFPlayerMini player;
bool playerListo = false;

bool pantallaEncendida = false;
bool redibujar = true;
int exprPintada = -1;
unsigned long ultimoMovimiento = 0, ultimoReloj = 0, ultimaDatos = 0;

int luz = 0, aire = 0;
float temp = NAN, hum = NAN;
unsigned long ultimaLectura = 0, ultimoEstado = 0, ultimoHistorial = 0, ultimaConfig = 0, ultimoWifi = 0;

// Configuración que llega desde la app (Firestore: users/{uid}/alarmas/* y users/{uid}/config/luces)
#define MAX_ALARMAS 10
struct AlarmaCfg {
  int hora;
  int minuto;
  bool activa;
  int dias;          // bits: L=1, M=2, X=4, J=8, V=16, S=32, D=64
  int sonido;        // número de pista en la SD: /MP3/0001.mp3 ... 0005.mp3
  float volumen;     // 0.0 a 1.0
  bool vibracion;
};
AlarmaCfg alarmas[MAX_ALARMAS];
int numAlarmas = 0;
int cfgColor = 2;
int cfgExpresion = -1;             // -1 automático; 0 contento, 1 dormido, 2 alerta, 3 sorprendido (desde la app)                  // 0 rojo, 1 amarillo, 2 verde, 3 azul, 4 magenta
bool cfgModoNoche = false;
bool cfgLuzNocturna = true;

bool alarmaSonando = false;
bool alarmaVibra = true;
unsigned long inicioAlarma = 0;
int minutoAlarmaDisparada = -1;

String idToken = "", uid = "";
unsigned long tokenObtenido = 0;

// ---------- LED RGB (colores sin PWM) ----------
void rgb(bool r, bool g, bool b) {
  if (RGB_ANODO_COMUN) { r = !r; g = !g; b = !b; }
  digitalWrite(RGB_R, r);
  digitalWrite(RGB_G, g);
  digitalWrite(RGB_B, b);
}

void rgbIndice(int i) {
  switch (i) {
    case 0: rgb(true, false, false); break;   // rojo
    case 1: rgb(true, true, false); break;    // amarillo
    case 2: rgb(false, true, false); break;   // verde
    case 3: rgb(false, false, true); break;   // azul
    default: rgb(true, false, true); break;   // magenta
  }
}

// ---------- Sensores ----------
void leerSensores() {
  luz = analogRead(LDR_PIN);
  aire = analogRead(MQ135_PIN);
  float t = dht.readTemperature(), h = dht.readHumidity();
  if (!isnan(t)) temp = t;
  if (!isnan(h)) hum = h;
}

// ---------- Alarma ----------
void iniciarAlarma(int sonido, float volumen, bool vibracion) {
  alarmaSonando = true;
  alarmaVibra = vibracion;
  inicioAlarma = millis();
  if (playerListo) {
    player.volume(constrain((int)(volumen * 30 + 0.5), 1, 30));
    player.playMp3Folder(sonido);          // /MP3/000N.mp3
  }
  Serial.printf("ALARMA: sonando (pista %d)\n", sonido);
}

void detenerAlarma() {
  alarmaSonando = false;
  if (playerListo) player.stop();
  Serial.println("ALARMA: detenida");
}

void revisarAlarma() {
  struct tm t;
  if (!getLocalTime(&t, 50)) return;
  int ahoraMin = t.tm_hour * 60 + t.tm_min;
  int bitHoy = (t.tm_wday + 6) % 7;                          // tm_wday: 0 = domingo -> bit 6 (D)
  if (ahoraMin != minutoAlarmaDisparada) minutoAlarmaDisparada = -1;   // rearma al cambiar el minuto

  if (!alarmaSonando && minutoAlarmaDisparada != ahoraMin) {
    for (int i = 0; i < numAlarmas; i++) {
      const AlarmaCfg &a = alarmas[i];
      if (!a.activa || !((a.dias >> bitHoy) & 1)) continue;
      if (a.hora * 60 + a.minuto != ahoraMin) continue;
      minutoAlarmaDisparada = ahoraMin;
      iniciarAlarma(a.sonido, a.volumen, a.vibracion);
      break;
    }
  }
  if (alarmaSonando && millis() - inicioAlarma >= DURACION_ALARMA) detenerAlarma();
  // Pasar la mano frente al sensor de proximidad detiene la alarma
  if (alarmaSonando && digitalRead(PROX_PIN) == LOW) detenerAlarma();
}

// Próxima alarma activa (hoy o en los próximos 7 días). Devuelve false si no hay ninguna.
bool proximaAlarma(int &h, int &m) {
  struct tm t;
  if (!getLocalTime(&t, 50)) return false;
  int ahoraMin = t.tm_hour * 60 + t.tm_min;
  int mejor = -1;
  for (int d = 0; d < 8; d++) {
    int bit = (t.tm_wday + 6 + d) % 7;
    for (int i = 0; i < numAlarmas; i++) {
      if (!alarmas[i].activa || !((alarmas[i].dias >> bit) & 1)) continue;
      int objetivo = alarmas[i].hora * 60 + alarmas[i].minuto;
      if (d == 0 && objetivo <= ahoraMin) continue;
      int falta = d * 1440 + objetivo - ahoraMin;
      if (mejor < 0 || falta < mejor) {
        mejor = falta;
        h = alarmas[i].hora;
        m = alarmas[i].minuto;
      }
    }
  }
  return mejor >= 0;
}

// Muestra en el monitor los errores del módulo MP3 (por qué no suena)
void revisarPlayer() {
  if (!playerListo || !player.available()) return;
  uint8_t tipo = player.readType();
  int valor = player.read();
  if (tipo == DFPlayerError) {
    const char* motivo = "error desconocido";
    switch (valor) {
      case 1: motivo = "no encuentra la tarjeta SD"; break;
      case 2: motivo = "modulo dormido"; break;
      case 3: motivo = "error de comunicacion serie"; break;
      case 4: motivo = "checksum incorrecto (cables RX/TX)"; break;
      case 5: motivo = "numero de pista fuera de rango"; break;
      case 6: motivo = "no encuentra el archivo (revisa /MP3/0001.mp3)"; break;
    }
    Serial.printf("DFPlayer ERROR %d: %s\n", valor, motivo);
  }
}

// ---------- Actuadores según el estado ----------
void actualizarActuadores(int movimiento) {
  bool oscuro = luz < UMBRAL_OSCURIDAD;

  // Luz nocturna: movimiento + oscuridad (si la app la tiene activada)
  digitalWrite(LED_PIN, (cfgLuzNocturna && movimiento == HIGH && oscuro) ? HIGH : LOW);

  // Vibrador: solo mientras suena la alarma
  digitalWrite(VIBRADOR_PIN, (alarmaSonando && alarmaVibra) ? HIGH : LOW);

  // LED RGB
  if (alarmaSonando) {
    bool on = (millis() / 300) % 2;               // rojo parpadeando
    rgb(on, false, false);
  } else if (!pantallaEncendida) {
    rgb(false, false, false);
  } else if (aire > UMBRAL_AIRE) {
    rgb(true, true, false);                       // amarillo: aire malo
  } else if (cfgModoNoche && oscuro) {
    rgb(false, false, false);                     // modo noche: sin luz de color
  } else {
    rgbIndice(cfgColor);                          // color elegido en la app
  }
}

// ---------- Pantalla TFT ----------
// Lo último que se dibujó (para no redibujar si nada cambió y evitar el parpadeo)
String horaPintada = "", subtituloPintado = "", datosPintados = "";
volatile bool nubeOk = false;

void dibujarHora() {
  struct tm t;
  char h[9] = "--:--:--";
  if (getLocalTime(&t, 50)) strftime(h, sizeof(h), "%H:%M:%S", &t);
  if (horaPintada == h) return;
  horaPintada = h;
  gfx->setTextColor(COL_TX, COL_BG);      // texto con fondo: no hace falta borrar antes
  gfx->setTextSize(6);
  gfx->setCursor(20, 20);
  gfx->print(h);
}

void dibujarSubtitulo() {
  char buf[32];
  uint16_t color = COL_MU;
  if (alarmaSonando) {
    strcpy(buf, "** ALARMA **");
    color = COL_RED;
  } else {
    int h = 0, m = 0;
    if (proximaAlarma(h, m)) snprintf(buf, sizeof(buf), "Proxima alarma %02d:%02d", h, m);
    else strcpy(buf, "Sin alarmas activas");
  }
  String clave = String(buf) + "|" + String(color);
  if (clave == subtituloPintado) return;
  subtituloPintado = clave;
  gfx->fillRect(20, 84, 300, 40, COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(color);
  gfx->setCursor(20, 90);
  gfx->print(buf);
}

// Cara del robot: 0 contento, 1 dormido, 2 alerta (aire malo), 3 alarma
void dibujarCara(int expr) {
  const int x = 330, y = 20, w = 130, h = 120;
  uint16_t c = (expr == 3) ? COL_RED : COL_AMB;
  gfx->fillRoundRect(x, y, w, h, 12, COL_CARD);
  switch (expr) {
    case 0:
      gfx->fillCircle(x + 35, y + 45, 10, c);
      gfx->fillCircle(x + 95, y + 45, 10, c);
      gfx->fillRoundRect(x + 35, y + 80, 60, 10, 5, c);
      break;
    case 1:
      gfx->fillRoundRect(x + 22, y + 45, 26, 5, 2, c);
      gfx->fillRoundRect(x + 82, y + 45, 26, 5, 2, c);
      gfx->fillRoundRect(x + 50, y + 85, 30, 5, 2, c);
      break;
    case 2:                                   // alerta: ojos "!" y boca recta
      gfx->fillRoundRect(x + 30, y + 22, 10, 34, 5, c);
      gfx->fillCircle(x + 35, y + 68, 5, c);
      gfx->fillRoundRect(x + 90, y + 22, 10, 34, 5, c);
      gfx->fillCircle(x + 95, y + 68, 5, c);
      gfx->fillRoundRect(x + 45, y + 96, 40, 8, 4, c);
      break;
    default:                                  // 3 alarma (rojo) y 4 sorprendido: ojos y boca redondos
      gfx->fillCircle(x + 35, y + 45, 14, c);
      gfx->fillCircle(x + 95, y + 45, 14, c);
      gfx->fillCircle(x + 65, y + 88, 9, c);
      break;
  }
}

void tarjeta(int x, const char* etiqueta, String valor, int tam) {
  const int y = 160, w = 105, h = 100;
  gfx->fillRoundRect(x, y, w, h, 10, COL_CARD);
  gfx->setTextColor(COL_MU);
  gfx->setTextSize(2);
  gfx->setCursor(x + 8, y + 10);
  gfx->print(etiqueta);
  gfx->setTextColor(COL_TX);
  gfx->setTextSize(tam);
  gfx->setCursor(x + 8, y + 50);
  gfx->print(valor);
}

void dibujarDatos(int mov) {
  String t = isnan(temp) ? String("--") : String(temp, 1) + "C";
  String h = isnan(hum) ? String("--") : String((int)hum) + "%";
  const char* l = luz < UMBRAL_OSCURIDAD ? "Baja" : "Alta";
  const char* a = aire > UMBRAL_AIRE ? "Mala" : "Buena";
  const char* wifi = WiFi.status() == WL_CONNECTED ? "OK" : "--";
  const char* nube = nubeOk ? "OK" : "--";
  String clave = t + "|" + h + "|" + l + "|" + a + "|" + (mov ? "1" : "0") + "|" + wifi + "|" + nube;
  if (clave == datosPintados) return;
  datosPintados = clave;

  tarjeta(20, "Temp", t, 3);
  tarjeta(135, "Hum", h, 3);
  tarjeta(250, "Luz", l, 2);
  tarjeta(365, "Aire", a, 2);

  gfx->fillRect(20, 275, 440, 30, COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_MU);
  gfx->setCursor(20, 280);
  gfx->print(mov ? "Mov: SI" : "Mov: NO");
  gfx->print("  WiFi:");
  gfx->print(wifi);
  gfx->print("  Nube:");
  gfx->print(nube);
}

void actualizarPantalla(int movimiento) {
  int expr;
  if (alarmaSonando) expr = 3;                                            // alarma
  else if (cfgExpresion >= 0) expr = (cfgExpresion == 3) ? 4 : cfgExpresion;   // elegida en la app (4 = sorprendido)
  else expr = (aire > UMBRAL_AIRE) ? 2 : ((luz < UMBRAL_OSCURIDAD) ? 1 : 0);    // automática
  if (redibujar) {
    gfx->fillScreen(COL_BG);
    horaPintada = "";
    subtituloPintado = "";
    datosPintados = "";
    dibujarCara(expr);
    exprPintada = expr;
    dibujarSubtitulo();
    dibujarHora();
    dibujarDatos(movimiento);
    ultimoReloj = ultimaDatos = millis();
    redibujar = false;
    return;
  }
  if (expr != exprPintada) {
    dibujarCara(expr);
    exprPintada = expr;
    dibujarSubtitulo();
  }
  if (millis() - ultimoReloj >= 200) {
    ultimoReloj = millis();
    dibujarHora();
  }
  if (millis() - ultimaDatos >= 1000) {
    ultimaDatos = millis();
    dibujarSubtitulo();
    dibujarDatos(movimiento);
  }
}

// ---------- Firebase ----------
bool iniciarSesion() {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(8000);
  String url = String("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=") + FIREBASE_API_KEY;
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  String body = String("{\"email\":\"") + USER_EMAIL + "\",\"password\":\"" + USER_PASS + "\",\"returnSecureToken\":true}";
  int code = http.POST(body);
  if (code != 200) {
    Serial.printf("Login Firebase fallo: %d\n", code);
    Serial.println(http.getString());
    http.end();
    return false;
  }
  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getString());
  http.end();
  if (err) return false;
  idToken = doc["idToken"].as<String>();
  uid = doc["localId"].as<String>();
  tokenObtenido = millis();
  nubeOk = true;
  Serial.println("Sesion Firebase iniciada");
  return true;
}

String urlBase() {
  return String("https://firestore.googleapis.com/v1/projects/") + PROJECT_ID +
         "/databases/(default)/documents/users/" + uid;
}

String cuerpoLectura(int mov) {
  time_t now = time(nullptr);
  struct tm t;
  gmtime_r(&now, &t);
  char ts[25];
  strftime(ts, sizeof(ts), "%Y-%m-%dT%H:%M:%SZ", &t);
  String b = "{\"fields\":{";
  if (!isnan(temp)) b += "\"temp\":{\"doubleValue\":" + String(temp, 1) + "},";
  if (!isnan(hum)) b += "\"hum\":{\"doubleValue\":" + String(hum, 1) + "},";
  b += "\"luz\":{\"integerValue\":\"" + String(luz) + "\"},";
  b += "\"aire\":{\"integerValue\":\"" + String(aire) + "\"},";
  b += "\"movimiento\":{\"booleanValue\":" + String(mov ? "true" : "false") + "},";
  b += "\"ts\":{\"timestampValue\":\"" + String(ts) + "\"}}}";
  return b;
}

bool enviar(const String& url, const char* metodo, const String& body) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(8000);
  if (!http.begin(client, url)) return false;
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", "Bearer " + idToken);
  int code = http.sendRequest(metodo, body);
  http.end();
  if (code == 200) Serial.printf("Firestore %s OK\n", metodo);
  else Serial.printf("Firestore %s fallo: %d\n", metodo, code);
  return code == 200;
}

// Lee un documento de Firestore; devuelve false si no existe todavía (404) o hay error
bool obtenerDoc(const String& ruta, JsonDocument& doc) {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(8000);
  if (!http.begin(client, urlBase() + "/" + ruta)) return false;
  http.addHeader("Authorization", "Bearer " + idToken);
  int code = http.GET();
  if (code != 200) {
    if (code != 404) Serial.printf("Firestore GET %s fallo: %d\n", ruta.c_str(), code);
    http.end();
    return false;
  }
  DeserializationError err = deserializeJson(doc, http.getString());
  http.end();
  return !err;
}

// Lee todas las alarmas de users/{uid}/alarmas (una por documento)
void leerAlarmas() {
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;
  http.setTimeout(8000);
  if (!http.begin(client, urlBase() + "/alarmas?pageSize=" + String(MAX_ALARMAS))) return;
  http.addHeader("Authorization", "Bearer " + idToken);
  int code = http.GET();
  if (code != 200) {
    Serial.printf("Firestore GET alarmas fallo: %d\n", code);
    http.end();
    return;
  }
  // Filtro: solo guardamos los campos que usamos (ahorra memoria)
  JsonDocument filtro;
  filtro["documents"][0]["fields"]["hora"]["integerValue"] = true;
  filtro["documents"][0]["fields"]["minuto"]["integerValue"] = true;
  filtro["documents"][0]["fields"]["activa"]["booleanValue"] = true;
  filtro["documents"][0]["fields"]["dias"]["integerValue"] = true;
  filtro["documents"][0]["fields"]["sonido"]["integerValue"] = true;
  filtro["documents"][0]["fields"]["volumen"]["doubleValue"] = true;
  filtro["documents"][0]["fields"]["vibracion"]["booleanValue"] = true;

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, http.getString(), DeserializationOption::Filter(filtro));
  http.end();
  if (err) {
    Serial.println("Alarmas: JSON invalido");
    return;
  }
  AlarmaCfg tmp[MAX_ALARMAS];
  int n = 0;
  for (JsonObject d : doc["documents"].as<JsonArray>()) {
    if (n >= MAX_ALARMAS) break;
    JsonObject f = d["fields"];
    AlarmaCfg &a = tmp[n++];
    a.hora = atoi(f["hora"]["integerValue"] | "7");
    a.minuto = atoi(f["minuto"]["integerValue"] | "0");
    a.activa = f["activa"]["booleanValue"] | true;
    a.dias = atoi(f["dias"]["integerValue"] | "127");
    a.sonido = constrain(atoi(f["sonido"]["integerValue"] | "1"), 1, 99);
    a.volumen = f["volumen"]["doubleValue"] | 0.66f;
    a.vibracion = f["vibracion"]["booleanValue"] | true;
    Serial.printf("Alarma %02d:%02d activa=%d dias=%d pista=%d vol=%.2f\n",
                  a.hora, a.minuto, a.activa, a.dias, a.sonido, a.volumen);
  }
  memcpy(alarmas, tmp, sizeof(AlarmaCfg) * n);
  numAlarmas = n;
  Serial.printf("Alarmas leidas: %d\n", n);
}

void leerConfig() {
  leerAlarmas();
  JsonDocument l;
  if (obtenerDoc("config/luces", l)) {
    JsonVariant f = l["fields"];
    const char* c = f["color"]["integerValue"].as<const char*>();
    if (c) cfgColor = atoi(c);
    const char* e = f["expresion"]["integerValue"].as<const char*>();
    if (e) cfgExpresion = atoi(e);
    if (!f["modoNoche"]["booleanValue"].isNull()) cfgModoNoche = f["modoNoche"]["booleanValue"].as<bool>();
    if (!f["luzNocturna"]["booleanValue"].isNull()) cfgLuzNocturna = f["luzNocturna"]["booleanValue"].as<bool>();
    Serial.printf("Config luces: color=%d modoNoche=%d luzNocturna=%d\n", cfgColor, cfgModoNoche, cfgLuzNocturna);
  }
}

void sincronizarFirebase() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (time(nullptr) < 1700000000) return;
  static unsigned long ultimoIntentoLogin = 0;
  if (idToken.isEmpty() || millis() - tokenObtenido > VIDA_TOKEN) {
    if (ultimoIntentoLogin != 0 && millis() - ultimoIntentoLogin < 300000) return;   // 5 min entre intentos
    ultimoIntentoLogin = millis();
    if (!iniciarSesion()) return;
  }

  if (millis() - ultimaConfig >= INTERVALO_CONFIG) {
    ultimaConfig = millis();
    leerConfig();
  }

  int mov = digitalRead(PIR_PIN);
  if (millis() - ultimoEstado >= INTERVALO_ESTADO) {
    ultimoEstado = millis();
    enviar(urlBase() + "/estado/actual", "PATCH", cuerpoLectura(mov));
  }
  if (millis() - ultimoHistorial >= INTERVALO_HISTORIAL) {
    ultimoHistorial = millis();
    enviar(urlBase() + "/lecturas", "POST", cuerpoLectura(mov));
  }
}

// Firebase corre en el núcleo 0; el loop (pantalla, alarma, sensores) sigue en el núcleo 1
void tareaFirebase(void *param) {
  for (;;) {
    sincronizarFirebase();
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}

// ---------- Setup ----------
void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
  pinMode(PROX_PIN, INPUT_PULLUP);
  pinMode(LED_PIN, OUTPUT);
  pinMode(VIBRADOR_PIN, OUTPUT);
  pinMode(RGB_R, OUTPUT);
  pinMode(RGB_G, OUTPUT);
  pinMode(RGB_B, OUTPUT);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);
  rgb(false, false, false);
  dht.begin();

  if (!gfx->begin(20000000)) Serial.println("Error al iniciar la pantalla TFT");
  COL_BG = gfx->color565(15, 18, 32);
  COL_CARD = gfx->color565(26, 31, 54);
  COL_AMB = gfx->color565(255, 181, 71);
  COL_TX = gfx->color565(237, 239, 247);
  COL_MU = gfx->color565(154, 160, 189);
  COL_RED = gfx->color565(255, 93, 93);
  gfx->fillScreen(COL_BG);
  gfx->setTextColor(COL_TX);
  gfx->setTextSize(3);
  gfx->setCursor(20, 20);
  gfx->println("Iniciando...");

  Serial2.begin(9600, SERIAL_8N1, DF_RX, DF_TX);
  if (player.begin(Serial2)) {
    player.volume(VOLUMEN);
    playerListo = true;
    Serial.println("DFPlayer listo");
  } else {
    Serial.println("DFPlayer NO detectado (revisa cables y tarjeta SD)");
  }

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  WiFi.setSleep(false);
  Serial.print("Conectando a WiFi");
  unsigned long inicioIntento = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - inicioIntento < 15000) {
    delay(300);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi conectado, sincronizando hora...");
    configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
    struct tm timeinfo;
    if (getLocalTime(&timeinfo, 10000)) Serial.println("Hora sincronizada correctamente");
    else Serial.println("No se pudo obtener la hora por NTP");
  } else {
    Serial.println("\nNo se pudo conectar al WiFi, la hora no estara disponible");
  }

  delay(500);
  digitalWrite(TFT_BL, LOW);        // pantalla apagada hasta detectar movimiento
  pantallaEncendida = false;
  Serial.println("Escribe 'a' en el monitor serial para probar la alarma ('s' para detenerla)");
  xTaskCreatePinnedToCore(tareaFirebase, "firebase", 16384, NULL, 1, NULL, 0);
}

// ---------- Loop ----------
void loop() {
  int movimiento = digitalRead(PIR_PIN);

  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'a' && !alarmaSonando) iniciarAlarma(1, VOLUMEN / 30.0f, true);
    if (c == 's' && alarmaSonando) detenerAlarma();
  }

  if (WiFi.status() != WL_CONNECTED && millis() - ultimoWifi > 30000) {
    ultimoWifi = millis();
    WiFi.reconnect();
  }

  if (millis() - ultimaLectura >= INTERVALO_LECTURA) {
    ultimaLectura = millis();
    leerSensores();
  }

  if (movimiento == HIGH) ultimoMovimiento = millis();

  // La pantalla se enciende con movimiento o mientras suena la alarma
  bool debeEstarEncendida = alarmaSonando ||
                            (ultimoMovimiento != 0 && millis() - ultimoMovimiento < TIEMPO_ENCENDIDA);
  if (debeEstarEncendida && !pantallaEncendida) {
    digitalWrite(TFT_BL, HIGH);
    pantallaEncendida = true;
    redibujar = true;
    Serial.println("Pantalla encendida");
  } else if (!debeEstarEncendida && pantallaEncendida) {
    digitalWrite(TFT_BL, LOW);
    pantallaEncendida = false;
    Serial.println("Pantalla apagada");
  }

  revisarAlarma();
  revisarPlayer();
  if (pantallaEncendida) actualizarPantalla(movimiento);
  actualizarActuadores(movimiento);
  delay(100);
}
