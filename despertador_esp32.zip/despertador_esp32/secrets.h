#pragma once

#define WIFI_SSID        "Fernando"
#define WIFI_PASS        "fernando11"

#define FIREBASE_API_KEY "AIzaSyBElEYqvBgp7F9gHA_Av94xuhn_2UlfaHs"
#define PROJECT_ID       "despertadorinteligente"
#define USER_EMAIL       "fdo@fdo.cl"
#define USER_PASS        "fernando1"